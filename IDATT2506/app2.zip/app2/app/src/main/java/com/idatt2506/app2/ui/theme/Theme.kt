package com.idatt2506.app2.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = RecipeBrown,
    onPrimary = RecipeSurface,
    secondary = RecipeGreen,
    tertiary = RecipeOrange,
    background = RecipeBackground,
    onBackground = RecipeDarkBrown,
    surface = RecipeSurface,
    onSurface = RecipeDarkBrown,
    surfaceVariant = RecipeCream,
    onSurfaceVariant = RecipeMutedBrown
)

@Composable
fun App2Theme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
