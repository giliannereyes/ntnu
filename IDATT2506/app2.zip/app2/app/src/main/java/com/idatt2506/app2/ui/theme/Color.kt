package com.idatt2506.app2.ui.theme

import androidx.compose.ui.graphics.Color

val RecipeCream = Color(0xFFF3E8CD)
val RecipeSurface = Color(0xFFFFFAF2)
val RecipeBackground = Color(0xFFFCF7FF)
val RecipeBrown = Color(0xFF965437)
val RecipeDarkBrown = Color(0xFF2E241F)
val RecipeMutedBrown = Color(0xFF8A6657)
val RecipeGreen = Color(0xFF7A914A)
val RecipeOrange = Color(0xFFC17045)
