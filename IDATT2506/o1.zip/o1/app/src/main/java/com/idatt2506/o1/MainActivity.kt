package com.idatt2506.o1

import android.app.Activity
import android.os.Bundle
import android.util.Log

class MainActivity : Activity() {
    companion object {
        private const val LOG_TAG = "O1Lifecycle"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.w(LOG_TAG, "onCreate called")
    }

    override fun onStart() {
        super.onStart()
        Log.d(LOG_TAG, "onStart called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG, "onResume called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(LOG_TAG, "onPause called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(LOG_TAG, "onStop called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.e(LOG_TAG, "onDestroy called")
    }
}
