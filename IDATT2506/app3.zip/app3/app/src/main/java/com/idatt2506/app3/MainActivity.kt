package com.idatt2506.app3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import com.idatt2506.app3.ui.theme.App3Theme

data class Friend(
    val name: String,
    val birthDate: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            App3Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    FriendRegistrationScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun FriendRegistrationScreen(modifier: Modifier = Modifier) {
    var name by rememberSaveable { mutableStateOf("") }
    var birthDate by rememberSaveable { mutableStateOf("") }
    var friends by remember { mutableStateOf(emptyList<Friend>()) }
    val canAddFriend = name.isNotBlank() && birthDate.isNotBlank()

    FriendRegistrationContent(
        name = name,
        onNameChange = { name = it },
        birthDate = birthDate,
        onBirthDateChange = { birthDate = it },
        friends = friends,
        canAddFriend = canAddFriend,
        onAddFriend = {
            if (!canAddFriend) return@FriendRegistrationContent

            friends = friends + Friend(
                name = name.trim(),
                birthDate = birthDate.trim()
            )
            name = ""
            birthDate = ""
        },
        modifier = modifier
    )
}

@Composable
fun FriendRegistrationContent(
    name: String,
    onNameChange: (String) -> Unit,
    birthDate: String,
    onBirthDateChange: (String) -> Unit,
    friends: List<Friend>,
    canAddFriend: Boolean,
    onAddFriend: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text(stringResource(R.string.name_label)) }
        )
        OutlinedTextField(
            value = birthDate,
            onValueChange = onBirthDateChange,
            label = { Text(stringResource(R.string.birth_date_label)) }
        )
        Button(
            onClick = onAddFriend,
            enabled = canAddFriend
        ) {
            Text(stringResource(R.string.add_friend_button))
        }
        LazyColumn {
            items(friends) { friend ->
                FriendItem(friend = friend)
            }
        }
    }
}

@Composable
fun FriendItem(friend: Friend, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(text = friend.name)
        Text(text = friend.birthDate)
    }
}

@Preview(showBackground = true)
@Composable
fun FriendItemPreview() {
    App3Theme {
        FriendItem(
            friend = Friend(
                name = "Ola Nordmann",
                birthDate = "01.01.2000"
            )
        )
    }
}

@Preview(showBackground = true)
@Composable
fun FriendRegistrationContentPreview() {
    App3Theme {
        FriendRegistrationContent(
            name = "",
            onNameChange = {},
            birthDate = "",
            onBirthDateChange = {},
            friends = emptyList(),
            canAddFriend = false,
            onAddFriend = {}
        )
    }
}
